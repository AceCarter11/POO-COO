import iut.*;

public class Segment extends ObjetTouchable {

	private double angle;
	/**
	 * vitesse en pixels/ms
	 */
	private double vitesse;
	/**
	 * position fictive de la tête (sera arrondie)
	 */
	private double posX;
	private double posY;
	/**
	 * collection de cases sur lesquelles la tête a tourné...
	 */
	private Position[] cases;
	private Position caseCourante;
	private double[] futursAngles;

	/**
	 * 
	 * @param j
	 * @param x
	 * @param y
	 * @param angle
	 */
	public Segment(Jeu j, int x, int y, double angle) {
		// TODO - implement Segment.Segment
		throw new UnsupportedOperationException();
	}

	/**
	 * Indique une chaîne identifiant le type de l'objet
	 */
	public String getTypeObjet() {
		// TODO - implement Segment.getTypeObjet
		throw new UnsupportedOperationException();
	}

	/**
	 * Action : effet d'une testerCollision entre l'objet et le paramÃ¨tre
	 * @param o
	 */
	public void effetCollision(Objet o) {
		// TODO - implement Segment.effetCollision
		throw new UnsupportedOperationException();
	}

	/**
	 * demande un changement (ultérieur) de direction du segment
	 * @param angle l'angle de direction
	 * @param pos
	 */
	public void changer(double angle, Position pos) {
		// TODO - implement Segment.changer
		throw new UnsupportedOperationException();
	}

	/**
	 * Fait Ã©voluer l'objet
	 * @param dt le temps Ã©coulÃ© en millisecondes depuis le prÃ©cÃ©dent appel
	 */
	public void evoluer(long dt) {
		// TODO - implement Segment.evoluer
		throw new UnsupportedOperationException();
	}

}