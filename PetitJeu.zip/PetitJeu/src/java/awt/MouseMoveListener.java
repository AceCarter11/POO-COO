package java.awt;

public interface MouseMoveListener {
    
}
