package java.awt;

public interface MouseListener {
    
}
