package java.awt;

public abstract class Graphics {
    
}
