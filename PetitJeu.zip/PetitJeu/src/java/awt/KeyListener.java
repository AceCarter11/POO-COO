package java.awt;

public interface KeyListener {

	/**
	 * 
	 * @param keyEvent
	 */
	void keyPress(int keyEvent);

}

