import java.awt.*;
import iut.*;

/**
 * Tête du serpent
 */
public class Tête extends Segment implements KeyListener {

	/**
	 * score du joueur
	 */
	private int score;

	public int getScore() {
		return this.score;
	}

	/**
	 * 
	 * @param j
	 */
	public Tête(Jeu j) {
		// TODO - implement Tête.Tête
		throw new UnsupportedOperationException();
	}

	/**
	 * Indique une chaîne identifiant le type de l'objet
	 */
	public String getTypeObjet() {
		// TODO - implement Tête.getTypeObjet
		throw new UnsupportedOperationException();
	}

	/**
	 * Action : effet d'une testerCollision entre l'objet et le paramÃ¨tre
	 * @param o
	 */
	public void effetCollision(Objet o) {
		// TODO - implement Tête.effetCollision
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param keyEvent
	 */
	public void keyPress(int keyEvent) {
		// TODO - implement Tête.keyPress
		throw new UnsupportedOperationException();
	}

}
