/**
 * représente une case de l'écran
 */
public class Position {

	private int ligne;
	private int colonne;

}