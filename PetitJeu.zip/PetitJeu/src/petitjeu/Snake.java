import iut.*;

public class Snake extends Jeu {

	/**
	 * crée tous les objets du jeu. Appelé en début de partie.
	 */
	public void creeObjets() {
		// TODO - implement Snake.creeObjets
		throw new UnsupportedOperationException();
	}

	/**
	 * Dessine le fond d'écran
	 * @param g la surface d'affichage
	 */
	public void dessinerArrierePlan(Graphics g) {
		// TODO - implement Snake.dessinerArrierePlan
		throw new UnsupportedOperationException();
	}

	/**
	 * Action à exécuter lorsque le jeu est perdu
	 */
	public void perdu() {
		// TODO - implement Snake.perdu
		throw new UnsupportedOperationException();
	}

	/**
	 * action à exécuter lorsque le jeu est gagné
	 */
	public void gagne() {
		// TODO - implement Snake.gagne
		throw new UnsupportedOperationException();
	}

	/**
	 * Le joueur a-t-il gagné ?
	 * RENVOIE FALSE
	 * @return true si la partie est gagnée
	 */
	public boolean aGagne() {
		// TODO - implement Snake.aGagne
		throw new UnsupportedOperationException();
	}

	/**
	 * Le joueur a-t-il perdu ?
	 * RENVOIE FALSE
	 * @return true si la partie est perdue
	 */
	public boolean aPerdu() {
		// TODO - implement Snake.aPerdu
		throw new UnsupportedOperationException();
	}

}

