import iut.*;

public class Fruit extends ObjetTouchable {

	/**
	 * 
	 * @param j
	 * @param x
	 * @param y
	 */
	public Fruit(Jeu j, int x, int y) {
		// TODO - implement Fruit.Fruit
		throw new UnsupportedOperationException();
	}

	/**
	 * Indique une chaîne identifiant le type de l'objet
	 */
	public String getTypeObjet() {
		// TODO - implement Fruit.getTypeObjet
		throw new UnsupportedOperationException();
	}

	/**
	 * Fait Ã©voluer l'objet
	 * VIDE
	 * @param dt le temps Ã©coulÃ© en millisecondes depuis le prÃ©cÃ©dent appel
	 */
	public void evoluer(long dt) {
		// TODO - implement Fruit.evoluer
		throw new UnsupportedOperationException();
	}

	/**
	 * Action : effet d'une testerCollision entre l'objet et le paramÃ¨tre
	 * @param o
	 */
	public void effetCollision(Objet o) {
		// TODO - implement Fruit.effetCollision
		throw new UnsupportedOperationException();
	}

}
