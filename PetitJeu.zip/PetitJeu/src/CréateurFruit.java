import iut.*;

/**
 * Objet invisible et non touchable servant à créer des fruits
 */
public class CréateurFruit extends Objet {

	private int tempsAvantCréation;

	/**
	 * 
	 * @param j
	 */
	public CréateurFruit(Jeu j) {
		// TODO - implement CréateurFruit.CréateurFruit
		throw new UnsupportedOperationException();
	}

	/**
	 * Teste la testerCollision entre deux objets
	 * RENVOIE FALSE
	 * @param o
	 * @return true si la testerCollision a eu lieu
	 */
	public boolean testerCollision(Objet o) {
		// TODO - implement CréateurFruit.testerCollision
		throw new UnsupportedOperationException();
	}

	/**
	 * Action : effet d'une testerCollision entre l'objet et le paramÃ¨tre
	 * VIDE
	 * @param o
	 */
	public void effetCollision(Objet o) {
		// TODO - implement CréateurFruit.effetCollision
		throw new UnsupportedOperationException();
	}

	/**
	 * Indique une chaîne identifiant le type de l'objet
	 */
	public String getTypeObjet() {
		// TODO - implement CréateurFruit.getTypeObjet
		throw new UnsupportedOperationException();
	}

	/**
	 * Fait Ã©voluer l'objet
	 * @param dt le temps Ã©coulÃ© en millisecondes depuis le prÃ©cÃ©dent appel
	 */
	public void evoluer(long dt) {
		// TODO - implement CréateurFruit.evoluer
		throw new UnsupportedOperationException();
	}

}

