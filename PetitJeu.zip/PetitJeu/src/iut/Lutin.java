package iut;

/**
 * Une classe représentant un Lutin, c'est à dire une image mouvante (personnage, objet, etc...)
 * @author aguidet
 * @author Kevin Glass
 */
public class Lutin {

	private final java.awt.Image image;

	/**
	 * Crée un nouveau sprite à partir d'une image
	 * @param i l'image de départ
	 */
	public Lutin(java.awt.Image i) {
		// TODO - implement Lutin.Lutin
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return la largeur du sprite
	 */
	public int largeur() {
		// TODO - implement Lutin.largeur
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @return la hauteur du sprite
	 */
	public int hauteur() {
		// TODO - implement Lutin.hauteur
		throw new UnsupportedOperationException();
	}

	/**
	 * Dessine le sprite
	 * @param g la surface d'affichage
	 * @param x la position gauche du sprite
	 * @param y la position haute du sprite
	 */
	public void dessiner(java.awt.Graphics g, int x, int y) {
		// TODO - implement Lutin.dessiner
		throw new UnsupportedOperationException();
	}

}