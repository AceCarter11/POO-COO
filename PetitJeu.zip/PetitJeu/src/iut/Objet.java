package iut;

import java.util.HashMap;

/**
 * Singleton permettant de construire ou récupérer les sprites à partir de leur nom
 * Le nom du sprite doit correspondre à un fichier .png
 * Le sprite doit être placé dans un dossier ressource de l'application
 * @author aguidet
 * @author Kevin Glass
 */
public class Objet {

	private static Lutins instance = null;
	private final java.util.HashMap sprites = new HashMap();

	private Objet() {
		// TODO - implement Lutins.Lutins
		throw new UnsupportedOperationException();
	}

	/**
	 * Obtient l'instance du magasin de sprites
	 * @return le magasin de sprites
	 */
	public static Lutins get() {
		// TODO - implement Lutins.get
		throw new UnsupportedOperationException();
	}

	/**
	 * Fournit un lutin à partir de son nom
	 * @param nom le nom symbolique du sprite
	 * @return le sprite construit
	 * @throws Exception si le sprite de ce nom n'existe pas ou ne peut pas etre chargé
	 */
	public Lutin lutin(String nom) throws Exception, Exception {
		// TODO - implement Lutins.lutin
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nom
	 */
	private Lutin charger(String nom) throws Exception, Exception {
		// TODO - implement Lutins.charger
		throw new UnsupportedOperationException();
	}

}