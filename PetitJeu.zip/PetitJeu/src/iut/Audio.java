package iut;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.SourceDataLine;

/**
 * Permet de jouer un fichier son (format wave uniquement)
 * @author aguidet
 * @author thehornycocoboy
 */
public class Audio {

	private AudioInputStream audioInputStream = null;
	private SourceDataLine line;
	private String soundFile;

	/**
	 * Charge un fichier son
	 * @param s le nom du son (sans chemin ni extension) Le fichier son doit avoir une extension wavLe fichier son doit être placé dans les ressources de l'application
	 */
	public Audio(String s) {
		// TODO - implement Audio.Audio
		throw new UnsupportedOperationException();
	}

	/**
	 * Joue le fichier son en arrière-plan
	 */
	public void run() {
		// TODO - implement Audio.run
		throw new UnsupportedOperationException();
	}

}