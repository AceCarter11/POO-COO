package iut;

/**
 * Représente un objet qui implémente la notion de testerCollision
 *  La testerCollision est ici basique (testerCollision de rectangles)
 * @author aguidet
 */
public abstract class ObjetTouchable extends Objet {

	/**
	 * Construit un objet touchable
	 * @param g le jeu contenant l'objet
	 * @param nom le nom de l'objet (sprite)
	 * @param x pixel gauche de départ
	 * @param y pixel haut de départ
	 */
	public ObjetTouchable(Jeu g, String nom, int x, int y) {
		// TODO - implement ObjetTouchable.ObjetTouchable
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param o
	 */
	public boolean testerCollision(Objet o) {
		// TODO - implement ObjetTouchable.testerCollision
		throw new UnsupportedOperationException();
	}

}