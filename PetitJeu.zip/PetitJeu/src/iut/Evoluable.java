package iut;

/**
 * Représente un objet qui évolue en fonction du temps
 * @author aguidet
 */
public interface Evoluable {

	/**
	 * Fait évoluer l'objet
	 * @param dt le temps écoulé en millisecondes depuis le précédent appel
	 */
	abstract void evoluer(long dt);

}
