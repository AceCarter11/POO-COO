package iut;

/**
 * Interface représentant un objet 2D capable de se dessiner
 * @author aguidet
 */
public interface Dessinable {

	/**
	 * Dessine l'objet sur la surface 2D
	 * @param g la surface 2D
	 */
	abstract void dessiner(java.awt.Graphics g) throws Exception, Exception;

}
