package iut;

import java.awt.Cursor;
import java.awt.Graphics;
import java.util.*;

/**
 * Représente un jeu de type "2D"
 * Est un écran d'affichage 2D (fenêtre principale)
 * Compose des Objets
 * @author aguidet
 * @author Kevin Glass
 */
public abstract class Jeu {

	private java.awt.image.BufferStrategy strategy;
	private boolean running = false;
	private final Collection<Objet> objets = new ArrayList<Objet>();
	private final Collection<Objet> objetsASupprimer = new ArrayList<Objet>();
	private final Collection<Objet> objetsACreer = new ArrayList<Objet>();
	private long lastLoopTime = 0;
	private Cursor old;

	/**
	 * Crée le jeu
	 * @param largeur la largeur en pixels de l'espace de jeu
	 * @param hauteur la hauteur en pixels de l'espace de jeu
	 * @param title le titre du jeu qui s'affichera dans la fenetre
	 */
	public Jeu(int largeur, int hauteur, String title) {
		// TODO - implement Jeu.Jeu
		throw new UnsupportedOperationException();
	}

	/**
	 * Ajoute un objet dans le jeu. L'objet sera ajouté au prochain "tour"
	 * @param o l'objet à insérer
	 */
	public void ajouter(Objet o) {
		// TODO - implement Jeu.ajouter
		throw new UnsupportedOperationException();
	}

	/**
	 * Supprime un objet du jeu au prochain "tour"
	 * @param o l'objet à supprimer du jeu
	 */
	public void supprimer(Objet o) {
		// TODO - implement Jeu.supprimer
		throw new UnsupportedOperationException();
	}

	/**
	 * Indique si un objet est dans le jeu
	 * @param o l'objet à tester
	 * @return true si l'objet est toujours dans le jeu
	 */
	public boolean estEnJeu(Objet o) {
		// TODO - implement Jeu.estEnJeu
		throw new UnsupportedOperationException();
	}

	/**
	 * largeur du jeu
	 * @return la largeur du jeu (pixels)
	 */
	public int largeur() {
		// TODO - implement Jeu.largeur
		throw new UnsupportedOperationException();
	}

	/**
	 * hauteur du jeu
	 * @return la hauteur du jeu (pixels)
	 */
	public int hauteur() {
		// TODO - implement Jeu.hauteur
		throw new UnsupportedOperationException();
	}

	/**
	 * Arrête le jeu
	 */
	public void stopper() {
		// TODO - implement Jeu.stopper
		throw new UnsupportedOperationException();
	}

	/**
	 * FIn du jeu, mort du joueur
	 */
	public void mourir() {
		// TODO - implement Jeu.mourir
		throw new UnsupportedOperationException();
	}

	/**
	 * lance le jeu. Celui-ci tourne jusqu'à la fin (gagné ou perdu)
	 */
	public void jouer() {
		// TODO - implement Jeu.jouer
		throw new UnsupportedOperationException();
	}

	/**
	 * Ajoute un objet interactif pouvant recevoir les évènements du clavier
	 * @param k l'objet à ajouter
	 */
	protected void ajouteEcouteurClavier(java.awt.event.KeyListener k) {
		// TODO - implement Jeu.ajouteEcouteurClavier
		throw new UnsupportedOperationException();
	}

	/**
	 * Ajoute un objet interactif pouvant recevoir les évènements de la souris
	 * @param k
	 */
	protected void ajouteEcouteurSouris(java.awt.event.MouseListener k) {
		// TODO - implement Jeu.ajouteEcouteurSouris
		throw new UnsupportedOperationException();
	}

	/**
	 * crée tous les objets du jeu. Appelé en début de partie.
	 */
	protected abstract void creeObjets();

	/**
	 * Dessine le fond d'écran
	 * @param g la surface d'affichage
	 */
	protected abstract void dessinerArrierePlan(Graphics g);

	/**
	 * Action à exécuter lorsque le jeu est perdu
	 */
	protected abstract void perdu();

	/**
	 * action à exécuter lorsque le jeu est gagné
	 */
	protected abstract void gagne();

	/**
	 * Le joueur a-t-il gagné ?
	 * @return true si la partie est gagnée
	 */
	protected abstract boolean aGagne();

	/**
	 * Le joueur a-t-il perdu ?
	 * @return true si la partie est perdue
	 */
	protected abstract boolean aPerdu();

	private void cacherCurseur() {
		// TODO - implement Jeu.cacherCurseur
		throw new UnsupportedOperationException();
	}

	private void montrerCurseur() {
		// TODO - implement Jeu.montrerCurseur
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param largeur
	 * @param hauteur
	 * @param title
	 */
	private void init(int largeur, int hauteur, String title) {
		// TODO - implement Jeu.init
		throw new UnsupportedOperationException();
	}

}